"""مهاجرت‌های یک‌باره و قابل گزارش که عمداً فقط با /update اجرا می‌شوند."""

from __future__ import annotations

import json

from sqlalchemy import delete, func, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

import config
from models import GameMeta, InventoryItem, MarketListing, User
from services import users


async def _already_done(session: AsyncSession, key: str) -> bool:
    return await session.get(GameMeta, key) is not None


async def _mark_done(session: AsyncSession, key: str, data: dict) -> None:
    session.add(GameMeta(key=key, value=json.dumps(data, ensure_ascii=False, separators=(",", ":"))))


async def _convert_gods_rows(session: AsyncSession, rows: list[InventoryItem]) -> dict:
    """ردیف‌های Gods انتخاب‌شده را با حفظ بهترین لول/دوام/equip به Demigod تبدیل می‌کند."""
    stats = {"converted": 0, "merged": 0, "equipped": 0}
    for source in rows:
        user = await session.get(User, source.user_id, with_for_update=True)
        if user is None:
            continue
        source_level = max(1, int(source.level or 1))
        source_max = users.armor_max_durability("gods", source_level)
        source_cur = users.armor_current_durability("gods", source_level, source.durability)
        source_ratio = source_cur / max(1, source_max)

        target = (await session.execute(
            select(InventoryItem).where(
                InventoryItem.user_id == source.user_id,
                InventoryItem.item_key == "demigod",
            ).with_for_update()
        )).scalar_one_or_none()
        if target is None:
            source.item_key = "demigod"
            target_max = users.armor_max_durability("demigod", source_level)
            source.durability = max(0, min(target_max, round(target_max * source_ratio)))
            stats["converted"] += 1
        else:
            target_level = max(1, int(target.level or 1))
            target_old_max = users.armor_max_durability("demigod", target_level)
            target_old_cur = users.armor_current_durability("demigod", target_level, target.durability)
            target_ratio = target_old_cur / max(1, target_old_max)
            target.level = max(source_level, target_level)
            target_new_max = users.armor_max_durability("demigod", target.level)
            best_ratio = max(source_ratio, target_ratio)
            target.durability = max(0, min(target_new_max, round(target_new_max * best_ratio)))
            await session.delete(source)
            stats["merged"] += 1
        if user.equipped_armor == "gods":
            user.equipped_armor = "demigod"
            stats["equipped"] += 1
    return stats


async def migrate_legacy_gods_armor(session: AsyncSession) -> dict:
    """زره خدایان دارندگان سقف قدیمی لول 20 را امن به نیمه‌خدایان تبدیل می‌کند."""
    marker = "gods20_demigod_v1"
    empty = {"done": False, "converted": 0, "merged": 0, "equipped": 0}
    if await _already_done(session, marker):
        return empty

    rows = list((await session.execute(
        select(InventoryItem)
        .join(User, User.id == InventoryItem.user_id)
        .where(InventoryItem.item_key == "gods", User.level <= 20)
        .with_for_update()
    )).scalars())
    stats = {"done": True, **await _convert_gods_rows(session, rows)}
    await _mark_done(session, marker, stats)
    return stats


async def migrate_player_xp_400k(session: AsyncSession) -> dict:
    """XP تاریخی را از منحنی قبلی بازسازی و روی جدول دقیق 400k نگاشت می‌کند."""
    marker = "player_xp_400k_v1"
    empty = {
        "done": False,
        "checked": 0,
        "raised": 0,
        "lowered": 0,
        "same": 0,
        "old_cap_with_xp": 0,
    }
    if await _already_done(session, marker):
        return empty
    if sum(config.PLAYER_XP_NEEDS) != config.PLAYER_XP_TOTAL_TO_MAX:
        raise RuntimeError("PLAYER_XP_NEEDS must total exactly 400,000")

    stats = dict(empty)
    stats["done"] = True
    rows = list((await session.execute(select(User).order_by(User.id).with_for_update())).scalars())
    for user in rows:
        old_level = min(max(1, int(user.level or 1)), config.MAX_LEVEL)
        old_residual = max(0, int(user.xp or 0))
        total = users.lifetime_xp(old_level, old_residual, config.LEGACY_PLAYER_XP_NEEDS)
        new_level, new_residual = users.level_from_lifetime_xp(total, config.PLAYER_XP_NEEDS)
        users.ensure_skills(user)
        if new_level > old_level:
            bonus = sum(
                config.SKILL_BONUS_LEVELS.get(level, config.SKILL_POINT_PER_LEVEL)
                for level in range(old_level + 1, new_level + 1)
            )
            user.skill_points = int(user.skill_points or 0) + bonus
            stats["raised"] += 1
        elif new_level < old_level:
            stats["lowered"] += 1
        else:
            stats["same"] += 1
        if old_level == 20 and old_residual > 0:
            stats["old_cap_with_xp"] += 1
        user.level = new_level
        user.xp = new_residual
        stats["checked"] += 1

    await _mark_done(session, marker, stats)
    return stats


async def sync_lifetime_xp_with_medals(session: AsyncSession) -> dict:
    """مدال کلی و XP کل عمر را بدون کم‌کردن هیچ‌کدام روی یک عدد واحد می‌نشاند."""
    marker = "xp_medals_lifetime_v1"
    empty = {
        "done": False,
        "checked": 0,
        "raised": 0,
        "same": 0,
        "from_medals": 0,
        "medals_raised": 0,
        "skill_points": 0,
    }
    if await _already_done(session, marker):
        return empty
    if sum(config.PLAYER_XP_NEEDS) != config.PLAYER_XP_TOTAL_TO_MAX:
        raise RuntimeError("PLAYER_XP_NEEDS must total exactly 400,000")

    stats = dict(empty)
    stats["done"] = True
    rows = list((await session.execute(select(User).order_by(User.id).with_for_update())).scalars())
    for user in rows:
        old_level = min(max(1, int(user.level or 1)), config.MAX_LEVEL)
        residual = max(0, int(user.xp or 0))
        calculated = users.lifetime_xp(old_level, residual, config.PLAYER_XP_NEEDS)
        medals = max(0, int(user.medals or 0))
        lifetime = max(calculated, medals)
        if medals > calculated:
            stats["from_medals"] += 1
        elif calculated > medals:
            stats["medals_raised"] += 1

        new_level, new_residual = users.level_from_lifetime_xp(lifetime, config.PLAYER_XP_NEEDS)
        users.ensure_skills(user)
        spent = sum(max(0, int(getattr(user, f"skill_{key}", 0) or 0)) for key in config.SKILLS)
        owned_points = max(0, int(user.skill_points or 0)) + spent
        missing = max(0, users.expected_skill_points(new_level) - owned_points)
        if missing:
            user.skill_points = max(0, int(user.skill_points or 0)) + missing
            stats["skill_points"] += missing

        if new_level > old_level:
            stats["raised"] += 1
        else:
            stats["same"] += 1
        user.level = new_level
        user.xp = new_residual
        user.medals = lifetime
        stats["checked"] += 1

    await _mark_done(session, marker, stats)
    return stats


async def migrate_underlevel_gods_armor(session: AsyncSession) -> dict:
    """بعد از اصلاح XP، همه Godsهای صاحبان زیر لول واقعی خرید را به Demigod تبدیل می‌کند."""
    marker = "gods_underlevel_demigod_v1"
    empty = {"done": False, "converted": 0, "merged": 0, "equipped": 0}
    if await _already_done(session, marker):
        return empty
    min_level = int(config.ARMORS["gods"]["min_level"])
    rows = list((await session.execute(
        select(InventoryItem)
        .join(User, User.id == InventoryItem.user_id)
        .where(InventoryItem.item_key == "gods", User.level < min_level)
        .with_for_update()
    )).scalars())
    stats = {"done": True, **await _convert_gods_rows(session, rows)}
    await _mark_done(session, marker, stats)
    return stats


async def repair_plasma_inventory(session: AsyncSession) -> dict:
    """خرابی migration قدیمی plasma→minigun را بدون دست‌زدن به گاتلینگ واقعی ترمیم می‌کند."""
    marker = "repair_plasma_inventory_v1"
    empty = {"done": False, "restored": 0, "merged": 0, "recreated": 0, "weapon_fixed": 0}
    if await _already_done(session, marker):
        return empty

    stats = dict(empty)
    stats["done"] = True
    # سلاح واقعی durability ندارد؛ minigun دارای durability امضای قطعی زره پلاسمایی rename‌شده است.
    corrupted = list((await session.execute(
        select(InventoryItem)
        .where(InventoryItem.item_key == "minigun", InventoryItem.durability.is_not(None))
        .order_by(InventoryItem.user_id)
        .with_for_update()
    )).scalars())
    for source in corrupted:
        owner = await session.get(User, source.user_id, with_for_update=True)
        source_level = max(1, int(source.level or 1))
        source_max = users.armor_max_durability("plasma", source_level)
        source_cur = users.armor_current_durability("plasma", source_level, source.durability)
        source_ratio = source_cur / max(1, source_max)
        target = (await session.execute(
            select(InventoryItem).where(
                InventoryItem.user_id == source.user_id,
                InventoryItem.item_key == "plasma",
            ).with_for_update()
        )).scalar_one_or_none()
        if target is None:
            source.item_key = "plasma"
            source.ammo = None
            source.durability = source_cur
            stats["restored"] += 1
        else:
            target_level = max(1, int(target.level or 1))
            target_max = users.armor_max_durability("plasma", target_level)
            target_cur = users.armor_current_durability("plasma", target_level, target.durability)
            target_ratio = target_cur / max(1, target_max)
            target.level = max(source_level, target_level)
            merged_max = users.armor_max_durability("plasma", target.level)
            target.durability = max(0, min(merged_max, round(merged_max * max(source_ratio, target_ratio))))
            target.ammo = None
            await session.delete(source)
            stats["merged"] += 1
        if owner is not None and owner.equipped_weapon == "minigun":
            owner.equipped_weapon = None
            stats["weapon_fixed"] += 1

    await session.flush()
    # وقتی پلاسما روی تن ثبت بوده ولی ردیفش در برخورد با گاتلینگ حذف شده، مالکیت قطعی است؛
    # level قبلی اثری ندارد، پس محافظه‌کارانه لول ۱ با دوام کامل برمی‌گردد.
    equipped_owners = list((await session.execute(
        select(User).where(User.equipped_armor == "plasma").order_by(User.id).with_for_update()
    )).scalars())
    for owner in equipped_owners:
        exists = (await session.execute(select(InventoryItem.id).where(
            InventoryItem.user_id == owner.id,
            InventoryItem.item_key == "plasma",
        ))).scalar_one_or_none()
        if exists is None:
            session.add(InventoryItem(
                user_id=owner.id,
                item_key="plasma",
                level=1,
                ammo=None,
                durability=users.armor_max_durability("plasma", 1),
            ))
            stats["recreated"] += 1

    await _mark_done(session, marker, stats)
    return stats


async def remove_boss_fragments(session: AsyncSession) -> dict:
    """فرگمنت، escrow مارکت و state معلق آن را یک‌بار و کامل بازنشسته می‌کند."""
    marker = "remove_boss_fragments_v1"
    empty = {"done": False, "users": 0, "fragments": 0, "listings": 0, "pending": 0}
    if await _already_done(session, marker):
        return empty

    user_count, fragment_total = (await session.execute(select(
        func.count(User.id),
        func.coalesce(func.sum(User.boss_fragments), 0),
    ).where(User.boss_fragments > 0))).one()
    listing_count = int((await session.execute(
        select(func.count(MarketListing.id)).where(MarketListing.item == "fragment")
    )).scalar_one())
    fragment_pending = or_(
        (User.pending_action == "mkqty") & (User.pending_value == "fragment"),
        (User.pending_action == "mkprice") & User.pending_value.like("fragment:%"),
    )
    pending_count = int((await session.execute(
        select(func.count(User.id)).where(fragment_pending)
    )).scalar_one())

    await session.execute(update(User).where(User.boss_fragments != 0).values(boss_fragments=0))
    await session.execute(delete(MarketListing).where(MarketListing.item == "fragment"))
    await session.execute(update(User).where(fragment_pending).values(
        pending_action=None, pending_value=None, pending_at=None, pending_chat_id=None,
    ))
    stats = {
        "done": True,
        "users": int(user_count or 0),
        "fragments": int(fragment_total or 0),
        "listings": listing_count,
        "pending": pending_count,
    }
    await _mark_done(session, marker, stats)
    return stats


async def retire_legacy_duels(session: AsyncSession) -> dict:
    """دوئل‌های sendDice باز نسخه قبل را دقیقاً یک بار refund می‌کند."""
    marker = "retire_duel_dice_v1"
    if await _already_done(session, marker):
        return {"done": False, "matches": 0, "refunded": 0}
    from services import gambling

    matches, refunded = await gambling.retire_legacy_active_matches(session)
    stats = {"done": True, "matches": matches, "refunded": refunded}
    await _mark_done(session, marker, stats)
    return stats
